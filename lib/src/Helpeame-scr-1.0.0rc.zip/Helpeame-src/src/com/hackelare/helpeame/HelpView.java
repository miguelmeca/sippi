/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.helpeame;

import com.hackelare.helpeame.view.HelpViewWin;
import com.hackelare.helpeame.xml.XMLIndiceParser;
import java.io.File;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdom.JDOMException;

/**
 * Clase de inicializacion para ver las ayudas en el Sistema
 * @author ghw674
 */
public class HelpView {
    
    private HelpViewWin win = null;
    
    private File indice =null;
    private File helpPdf = null;
    
    public HelpView(File indice,File helpPdf)
    {
        if(this.win==null)
        {
            this.indice = indice;
            this.helpPdf = helpPdf;
            this.win = new HelpViewWin(indice,helpPdf,0);
        }
        else
        {
            System.out.println("El HelpView ya esta creado, se reutiliza");
        }
    }

    /**
     * Abre la ayuda en un capitulo y titulo seleccionado
     * @param nroCapitulo
     * @param nroTitulo
     * @return 
     */
    public void view(int nroCapitulo, int nroTitulo)
    {
        if(!this.win.isVisible())
        {
            this.win.setVisible(true);
        }
        else
        {
            this.win.toFront();
        }
        this.win.goToPage(getPageFrom(nroCapitulo,nroTitulo));
    }
    
    /**
     * Abre la ayuda al comienzo del capitulo seleccionado
     * @param nroCapitulo 
     */
    public void view(int nroCapitulo)
    {
        if(this.win!=null)
        {
            if(!this.win.isVisible())
            {
                this.win.setVisible(true);
            }
            else
            {
                this.win.toFront();
            }
            this.win.goToPage(getPageFrom(nroCapitulo));
        }
        else
        {
            System.out.println("Algun cochinudo errror, el View es NULL");    
        }
    }
    
    /**
     * Abre la ayuda en la caratula
     */
    public void view()
    {
        if(!this.win.isVisible())
        {
            this.win.setVisible(true);
        }
        else
        {
            this.win.toFront();
        }
        this.win.goToPage(1);
    }

    private int getPageFrom(int nroCapitulo, int nroTitulo)  {

        XMLIndiceParser xmlParser = new XMLIndiceParser(indice);
        
        try {
            return xmlParser.readPageFrom(nroCapitulo,nroTitulo);
        } catch (JDOMException ex) {
            System.out.println("Error en el parseo del XML");
            JOptionPane.showMessageDialog(new JFrame(),"Error en el parseo del XML");
        } catch (IOException ex) {
            System.out.println("Imposible abrir el archivo");
            JOptionPane.showMessageDialog(new JFrame(),"Imposible abrir el archivo de ayuda");
        }
        return 0;
        
    }
    
    private int getPageFrom(int nroCapitulo) {

        XMLIndiceParser xmlParser = new XMLIndiceParser(indice);
        
        try {
            return xmlParser.readPageFrom(nroCapitulo);
        } catch (JDOMException ex) {
            System.out.println("Error en el parseo del XML");
            JOptionPane.showMessageDialog(new JFrame(),"Error en el parseo del XML");
        } catch (IOException ex) {
            System.out.println("Imposible abrir el archivo");
            JOptionPane.showMessageDialog(new JFrame(),"Imposible abrir el archivo de ayuda");
        }
        return 0;

    }
    
    
}
