/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.helpeame.view;

/**
 *
 * @author ghw674
 */
public class TreeNode {
    
    private String nombre;
    
    private int idCapitulo;
    private int idTitulo;
    private int hoja;

    public int getHoja() {
        return hoja;
    }

    public void setHoja(int hoja) {
        this.hoja = hoja;
    }

    public int getIdCapitulo() {
        return idCapitulo;
    }

    public void setIdCapitulo(int idCapitulo) {
        this.idCapitulo = idCapitulo;
    }

    public int getIdTitulo() {
        return idTitulo;
    }

    public void setIdTitulo(int idTitulo) {
        this.idTitulo = idTitulo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
    
    
    
}
