/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.helpeame.xml;

import com.hackelare.helpeame.view.TreeNode;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.swing.tree.DefaultMutableTreeNode;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author ghw674
 */
public class XMLIndiceParser {

    private static final String TAG_capitulo = "capitulo";
    private static final String TAG_titulo = "titulo";
    
    private static final String ATTR_id = "id";
    private static final String ATTR_nombre = "nombre";
    private static final String ATTR_hoja = "hoja";
    
    SAXBuilder builder = new SAXBuilder();
    private File xml = null;
    
    public XMLIndiceParser(File xml) 
    {
        this.xml = xml;
    }
       
    public void readToTree(DefaultMutableTreeNode rootTreeNode) throws JDOMException, IOException
    {
        Document document = (Document) builder.build(this.xml);
        Element rootNode = document.getRootElement();
        List list = rootNode.getChildren(TAG_capitulo);
        
        for (int i = 0; i < list.size(); i++) {

           Element node = (Element) list.get(i);
           System.out.println(">" + node.getAttributeValue(ATTR_id)+"|"+node.getAttributeValue(ATTR_nombre)+"|"+node.getAttributeValue(ATTR_hoja));
           
           TreeNode nodo = new TreeNode();
           nodo.setNombre(node.getAttributeValue(ATTR_nombre));
           nodo.setIdCapitulo(Integer.parseInt(node.getAttributeValue(ATTR_id)));
           nodo.setIdTitulo(0);
           nodo.setHoja(Integer.parseInt(node.getAttributeValue(ATTR_hoja)));
           
           DefaultMutableTreeNode cap = new DefaultMutableTreeNode(nodo);
           rootTreeNode.add(cap);
           
           List listTitulo = node.getChildren(TAG_titulo);
           for (int j = 0; j < listTitulo.size(); j++) {
               Element nodeTitulo = (Element) listTitulo.get(j);
               System.out.println("    >" + nodeTitulo.getAttributeValue(ATTR_id)+"|"+nodeTitulo.getText()+"|"+nodeTitulo.getAttributeValue(ATTR_hoja));
               
               TreeNode nodo2 = new TreeNode();
               nodo2.setNombre(nodeTitulo.getText());
               nodo2.setIdCapitulo(Integer.parseInt(node.getAttributeValue(ATTR_id)));
               nodo2.setIdTitulo(Integer.parseInt(nodeTitulo.getAttributeValue(ATTR_id)));
               nodo2.setHoja(Integer.parseInt(nodeTitulo.getAttributeValue(ATTR_hoja)));
               
               DefaultMutableTreeNode title = new DefaultMutableTreeNode(nodo2);
               cap.add(title);
               
           }
	}          
    }

    public int readPageFrom(int nroCapitulo, int nroTitulo) throws JDOMException, IOException {
       
        Document document = (Document) builder.build(this.xml);
        Element rootNode = document.getRootElement();
        List list = rootNode.getChildren(TAG_capitulo);
        
        for (int i = 0; i < list.size(); i++) {

           Element node = (Element) list.get(i);
           System.out.println(">" + node.getAttributeValue(ATTR_id)+"|"+node.getAttributeValue(ATTR_nombre)+"|"+node.getAttributeValue(ATTR_hoja));
                      
           List listTitulo = node.getChildren(TAG_titulo);
           for (int j = 0; j < listTitulo.size(); j++) {
               Element nodeTitulo = (Element) listTitulo.get(j);
               System.out.println("    >" + nodeTitulo.getAttributeValue(ATTR_id)+"|"+nodeTitulo.getText()+"|"+nodeTitulo.getAttributeValue(ATTR_hoja));
               
               if(Integer.parseInt( nodeTitulo.getAttributeValue(ATTR_id) )==nroTitulo && Integer.parseInt(node.getAttributeValue(ATTR_id))==nroCapitulo)
               {
                   return Integer.parseInt(nodeTitulo.getAttributeValue(ATTR_hoja));
               }
               
           }
	}  
        return 0;
        
    }

    public int readPageFrom(int nroCapitulo) throws JDOMException, IOException {
        Document document = (Document) builder.build(this.xml);
        Element rootNode = document.getRootElement();
        List list = rootNode.getChildren(TAG_capitulo);
        
        for (int i = 0; i < list.size(); i++) {

           Element node = (Element) list.get(i);
           System.out.println(">" + node.getAttributeValue(ATTR_id)+"|"+node.getAttributeValue(ATTR_nombre)+"|"+node.getAttributeValue(ATTR_hoja));
                      
               if(Integer.parseInt(node.getAttributeValue(ATTR_id))==nroCapitulo)
               {
                   return Integer.parseInt(node.getAttributeValue(ATTR_hoja));
               }
	}  
        return 0;
    }
    
}
