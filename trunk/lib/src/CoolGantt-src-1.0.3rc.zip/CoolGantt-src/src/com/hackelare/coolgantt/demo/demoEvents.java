/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt.demo;

import com.hackelare.coolgantt.ICoolGanttEvent;
import java.util.Date;

/**
 * @author ghw674
 */
public class demoEvents implements ICoolGanttEvent {

    @Override
    public Date inGetProjectStartDate() {
        return new Date();
    }

    @Override
    public Date inGetProjectEndDate() {
        return new Date();
    }

    @Override
    public void outClickPhase(int id) {
        System.out.println("COOLGANTTDEMO: Out Click Phrase > id:"+id);
    }

    @Override
    public void outMovePhase(int id, Date ini) {
        System.out.println("COOLGANTTDEMO: Out Move Phrase > id:"+id+" | "+ini.toString());
    }

    @Override
    public void outExtendPhaseBackward(int id, Date ini) {
        System.out.println("COOLGANTTDEMO: Out Extend Phrase Back > id:"+id+" | "+ini.toString());
    }

    @Override
    public void outExtendPhaseForward(int id, Date ini) {
        System.out.println("COOLGANTTDEMO: Out Extend Phrase Forward > id:"+id+" | "+ini.toString());
    }
    
}
