package com.hackelare.coolgantt.legacy.proxy;

import com.hackelare.coolgantt.ICoolGanttEvent;
import java.beans.EventHandler;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Descripción:
 * @version 1.0
 * @author Iuga
 * @cambios
 * @todo
 */

public class SystemEventProxy {

    private static ICoolGanttEvent eventHandler;
    
    public static void setInstance(ICoolGanttEvent demoEvents) {
        SystemEventProxy.eventHandler = demoEvents;
    }

    private SystemEventProxy(){}

    public static ICoolGanttEvent getInstance()
    {
        return SystemEventProxy.eventHandler;
    }
 
}
