/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt.demo;

/**
 *
 * @author ghw674
 */
public class demoTypes {
    
    public static String TYPE_NORMAL = "NORMAL";
    public static String TYPE_TRANSPORTE = "TRANSPORTE";
    public static String TYPE_MONTAJE = "MONTAJE";
    
}
