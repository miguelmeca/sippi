/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.util.ArrayList;

/**
 *
 * @author ghw674
 */
public class CoolGanttModel {
    
    private ArrayList<CoolGanttPhase> phaseList;
    private CoolGanttTypeModel model;

    public CoolGanttModel() 
    {
        phaseList = new ArrayList<CoolGanttPhase>();
        model = new CoolGanttTypeModel();
    }

    public CoolGanttModel(ArrayList<CoolGanttPhase> phaseList, CoolGanttTypeModel model) {
        this.phaseList = phaseList;
        this.model = model;
    }

    public ArrayList<CoolGanttPhase> getPhaseList() {
        return phaseList;
    }

    public CoolGanttTypeModel getTypeModel() {
        return model;
    }

    public void setTypeModel(CoolGanttTypeModel model) {
        this.model = model;
    }
    
    public void addPhase(CoolGanttPhase phase){
        phaseList.add(phase);
    }
    
    public void addPhaseIn(CoolGanttPhase phase,CoolGanttPhase parent){
      CoolGanttPhase p = (CoolGanttPhase)phaseList.get(phaseList.indexOf(parent));
      p.addSubsequentPhase(phase);
    }

    public void SortPhases(){
        //TODO: Sort by date ??
    }
    
    
            
            
    
}
