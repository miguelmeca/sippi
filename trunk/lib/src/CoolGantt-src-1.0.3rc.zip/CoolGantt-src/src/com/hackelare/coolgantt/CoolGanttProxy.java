/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import com.hackelare.coolgantt.legacy.model.TaskImpl;
import com.hackelare.coolgantt.legacy.proxy.GraphProxy;
import com.hackelare.coolgantt.legacy.proxy.SystemEventProxy;
import java.awt.Point;
import java.util.Date;
import java.util.Iterator;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * @author ghw674
 */
class CoolGanttProxy implements ICoolGantt {

    private GraphProxy proxy;
    private CoolGanttModel model;
    private JComponent graph;
    
    public CoolGanttProxy() {
        proxy = new GraphProxy();
        model = new CoolGanttModel();
    }

    @Override
    public JComponent getComponent() {
        graph = (JComponent) proxy.buildGraph();
        return graph;
    }

    @Override
    public void refresh() {
        graph = (JComponent) proxy.buildGraph();
        graph.repaint();
    }

    @Override
    public void setModel(CoolGanttModel model) {
        // We need to transform the new model in the old one.
        this.model = model;
        // Refresh
        //refreshModel();
    }
    
    @Override
    public void refreshModel()
    {
        // Empty old model
        proxy = new GraphProxy();
        // Iterate in all the phases and add them to the model
        Iterator<CoolGanttPhase> it = model.getPhaseList().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase cgp = it.next();
            addPhases(cgp);
        }     
        refresh();
    }
 
    private void addPhases(CoolGanttPhase cgp)
    {
        if(cgp.getStartDate()!=null && cgp.getEndDate()!=null)
        {
            if(cgp.isEditable())
            {
                proxy.addEtapa(cgp.getId(),cgp.getNombre(),cgp.getStartDate(),cgp.getEndDate(),model.getTypeModel().getColor(cgp.getType()));
            }
            else
            {
                proxy.addEtapaNoEditable(cgp.getId(),cgp.getNombre(),cgp.getStartDate(),cgp.getEndDate());
            }  

            // Add children

            Iterator<CoolGanttPhase> it = cgp.getSubsequentPhases().iterator();
            while (it.hasNext()) 
            {
                CoolGanttPhase cgpChild = it.next();
                //addPhases(cgpChild);
                proxy.setEtapaPredecesora(cgp.getId(),cgpChild.getId());
            }
        }
        else
        {
            System.err.println("[ERROR] No puede agregar una tarea sin fecha de inicio o fin\nAmbos son datos requeridos!");
        }
    }

    @Override
    public CoolGanttModel getModel() {
        return model;
    }

    @Override
    public void addPhase(int id, String nombre, Date fechaInicio, Date FechaFin) {
        
        //System.out.println("GanttProxy: Add Phrase (Data)");
        CoolGanttPhase p = new CoolGanttPhase();
        p.setId(id);
        p.setNombre(nombre);
        p.setStartDate(fechaInicio);
        p.setEndDate(FechaFin);
        model.addPhase(p);
        //refreshModel(); 
    }

    @Override
    public void addPhase(CoolGanttPhase phase) {
        model.addPhase(phase);
        //refreshModel();
    }

    @Override
    public void addPhaseDisabled(int id, String nombre, Date fechaInicio, Date FechaFin) {
        
        //System.out.println("GanttProxy: Add Phrase (Data)(Disabled)");
        CoolGanttPhase p = new CoolGanttPhase();
        p.setId(id);
        p.setNombre(nombre);
        p.setStartDate(fechaInicio);
        p.setEndDate(FechaFin);
        p.setEditable(false);
        model.addPhase(p);
        //refreshModel();
    }

    @Override
    public void addPhaseDisabled(CoolGanttPhase phase) {
        //System.out.println("GanttProxy: Add Phrase (Phase)(Disabled)");
        phase.setEditable(false);
        model.addPhase(phase);
        //refreshModel();
    }

    @Override
    public CoolGanttPhase getPhase(int id) {
        // We must search in all the phases and subphases
        // return only the firts ocurrence
        Iterator<CoolGanttPhase> it = model.getPhaseList().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase cgp = it.next();
            if(cgp.getId()==id)
            {
                return cgp;
            }
            else
            {
                CoolGanttPhase tmp = getPhase(cgp,id);
                if(tmp!=null)
                {
                    return tmp;
                }                   
            }
        }   
        return null;
    }
    
    private CoolGanttPhase getPhase(CoolGanttPhase cgp,int id)
    {
        Iterator<CoolGanttPhase> it = cgp.getSubsequentPhases().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase pp = it.next();
            if(pp.getId()==id)
            {
                return pp;
            }
            else
            {
                CoolGanttPhase tmp = getPhase(cgp,id);
                if(tmp!=null)
                {
                    return tmp;
                }                   
            }
        }
        return null;
    }

    @Override
    public void removePhase(int id) 
    {
        // We must search in all the phases and subphases
        // remove all ocurrences
        Iterator<CoolGanttPhase> it = model.getPhaseList().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase cgp = it.next();
            if(cgp.getId()==id)
            {
                it.remove();
            }
            removePhase(cgp,id);
        }
    }
    
    public void removePhase(CoolGanttPhase cgp,int id) 
    {
        // We must search in all the phases and subphases
        // remove all ocurrences
        Iterator<CoolGanttPhase> it = cgp.getSubsequentPhases().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase pp = it.next();
            if(pp.getId()==id)
            {
                it.remove();
            }
            removePhase(cgp,id);
        }   
    }
    

    @Override
    public void setFocusToday() {
        proxy.setFocoFechaActual();
    }

    @Override
    public void setZoomIn() {
        proxy.setZoomIn();
    }

    @Override
    public void setZoomOut() {
        proxy.setZoomOut();
    }

    @Override
    public void moveRight() {
        proxy.moverDerecha();
    }

    @Override
    public void moveLeft() {
        proxy.moverIzquierda();
    }

    @Override
    public void setYearView() {
        proxy.setVistaAnual();
    }

    @Override
    public void setWeeklyView() {
        proxy.setVistaSemanal();
    }

    @Override
    public void setEventHandler(ICoolGanttEvent demoEvents) 
    {
        SystemEventProxy.setInstance(demoEvents);
    }

    @Override
    public CoolGanttPhase getPhase(Point location){
        
        TaskImpl task = proxy.getTarea(location);
        if(task==null)
        {
            System.out.println("[DEBUG] Task in Point == NULL");
            return null;
        }
        // We must search in all the phases and subphases
        // return only the firts ocurrence
        Iterator<CoolGanttPhase> it = model.getPhaseList().iterator();
        while (it.hasNext()) 
        {
            CoolGanttPhase cgp = it.next();
            System.out.println("[DEBUG] CGP ID="+cgp.getId()+" TASK ID="+task._id);
            if(cgp.getId()==Integer.parseInt(task._id))
            {
                return cgp;
            }
            else
            {
                CoolGanttPhase tmp = getPhase(cgp,Integer.parseInt(task._id));
                if(tmp!=null)
                {
                    return tmp;
                }                   
            }
        }   
        return null;
    }
    
}
