/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author ghw674
 */
public class CoolGanttPhase {
    
    private int id;
    private String nombre;
    private Date startDate;
    private Date endDate;
    private ArrayList<CoolGanttPhase> subsequentPhases;
    private String type;
    
    private boolean _isEditable;

    public CoolGanttPhase() {
        subsequentPhases = new ArrayList<CoolGanttPhase>();
        _isEditable = true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void addSubsequentPhase(CoolGanttPhase pphase){
        subsequentPhases.add(pphase);
    }

    public ArrayList<CoolGanttPhase> getSubsequentPhases() {
        return subsequentPhases;
    }

    public boolean isEditable() {
        return _isEditable;
    }

    public void setEditable(boolean _isEditable) {
        this._isEditable = _isEditable;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    
    
    
}
