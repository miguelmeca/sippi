/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt.legacy.model;

import java.awt.Color;
import org.junit.Test;

/**
 *
 * @author ghw674
 */
public class ColorLabelTest {
    
    public ColorLabelTest() {
    }

    /**
     * Test of toLighterColor method, of class ColorLabel.
     */
    @Test
    public void testToLighterColor() {
        
        Color c = new Color(160,190,250);
        Color result = ColorLabel.toLighterColor(c);

        getColorToString(result);

        result = ColorLabel.toLighterColor(result);
        getColorToString(result);
        
        result = ColorLabel.toLighterColor(result);
        getColorToString(result);
        
        result = ColorLabel.toLighterColor(result);
        getColorToString(result);
        
        result = ColorLabel.toLighterColor(result);
        getColorToString(result);
        
        result = ColorLabel.toLighterColor(result);
        getColorToString(result);
    }
    
    private void getColorToString(Color result)
    {
        System.out.println("RGB:"+result.getRed()+"|"+result.getGreen()+"|"+result.getBlue());
    }
}
