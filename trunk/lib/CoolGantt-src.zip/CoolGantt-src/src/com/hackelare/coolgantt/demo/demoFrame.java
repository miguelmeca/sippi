/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * demoFrame.java
 *
 * Created on Nov 11, 2011, 3:20:32 PM
 */
package com.hackelare.coolgantt.demo;

import com.hackelare.coolgantt.CoolGanttFactory;
import com.hackelare.coolgantt.CoolGanttModel;
import com.hackelare.coolgantt.CoolGanttPhase;
import com.hackelare.coolgantt.CoolGanttTypeModel;
import com.hackelare.coolgantt.CoolGanttUtils;
import com.hackelare.coolgantt.ICoolGantt;
import com.hackelare.coolgantt.legacy.model.ColorLabel;
import com.hackelare.coolgantt.legacy.proxy.SystemEventProxy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * @author ghw674
 */
public class demoFrame extends javax.swing.JFrame {

    ICoolGantt graph;
    JComponent grafico;
    
    /** Creates new form demoFrame */
    public demoFrame() {
        //initGraph();
        initComponents();
        initGraph();
        this.setSize(700,450);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        btnPrint = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jToolBar1.setRollover(true);

        btnPrint.setText("Grafico a Imagen");
        btnPrint.setFocusable(false);
        btnPrint.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPrint.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });
        jToolBar1.add(btnPrint);

        getContentPane().add(jToolBar1, java.awt.BorderLayout.PAGE_START);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CoolGantt 1.0 Demo ( Esteban Del Boca)");
        getContentPane().add(jLabel1, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed

        printGantt();
        
    }//GEN-LAST:event_btnPrintActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(demoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(demoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(demoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(demoFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new demoFrame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPrint;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JToolBar jToolBar1;
    // End of variables declaration//GEN-END:variables

    private void initGraph() 
    {
        graph = CoolGanttFactory.create();
        graph.setEventHandler(new demoEvents());
        
        initTypeModel();
        initModel();
        
        grafico = graph.getComponent();
        add(grafico,BorderLayout.CENTER);
        pack();
        setVisible(true);
    }

    private void initModel() {

            // Create a new Phrase
            CoolGanttPhase p1 = new CoolGanttPhase();
            p1.setEditable(true);
            p1.setId(1);
            p1.setNombre("1.Phase Test");
            p1.setType(demoTypes.TYPE_NORMAL);
            p1.setStartDate(new Date());
            p1.setEndDate(fechaMas(new Date(),5));
            
            // Create a new Phrase
            CoolGanttPhase p2 = new CoolGanttPhase();
            p2.setEditable(true);
            p2.setId(2);
            p2.setNombre("2.Phase Test");
            p2.setType(demoTypes.TYPE_TRANSPORTE);
            p2.setStartDate(fechaMas(new Date(),5));
            p2.setEndDate(fechaMas(new Date(),10));      
            
            // Create a new Phrase
            CoolGanttPhase p3 = new CoolGanttPhase();
            p3.setEditable(false);
            p3.setId(3);
            p3.setNombre("X.Phase Test");
            p3.setStartDate(fechaMas(new Date(),10));
            p3.setEndDate(fechaMas(new Date(),20));  
       
            // Create a new Phrase
            CoolGanttPhase p4 = new CoolGanttPhase();
            p4.setId(4);
            p4.setNombre("3.Phase Test@");
            p4.setStartDate(fechaMas(new Date(),20));
            p4.setEndDate(fechaMas(new Date(),30));    
            
            // Create a new Phrase
            CoolGanttPhase p5 = new CoolGanttPhase();
            p5.setEditable(true);
            p5.setId(5);
            p5.setNombre("4.Phase Test@@");
            p5.setStartDate(fechaMas(new Date(),10));
            p5.setEndDate(fechaMas(new Date(),20));  
            
            // Set dependencies
            p2.addSubsequentPhase(p1);
            //p4.addSubsequentPhase(p2);
            p5.addSubsequentPhase(p1);
            
        graph.addPhase(p1);
        graph.addPhase(p2);
        graph.addPhase(p3);
        graph.addPhase(p4);
        graph.addPhase(p5);

        graph.refreshModel();
        
        //graph.refresh();
        //pack();
    }
    
    private Date fechaMas(Date fch, int dias){
         Calendar cal = new GregorianCalendar();
         cal.setTimeInMillis(fch.getTime());
         cal.add(Calendar.DATE, dias);
         return new Date(cal.getTimeInMillis());
    }

    private void initTypeModel() {
        CoolGanttTypeModel typeModel = new CoolGanttTypeModel();
        typeModel.addType(demoTypes.TYPE_NORMAL,ColorLabel.COLOR_LABELS[0]);
        typeModel.addType(demoTypes.TYPE_TRANSPORTE,ColorLabel.COLOR_LABELS[1]);
        typeModel.addType(demoTypes.TYPE_MONTAJE,ColorLabel.COLOR_LABELS[2]);
        graph.getModel().setTypeModel(typeModel);
    }
    
    private void printGantt()
    {
        Image port = CoolGanttUtils.getGanttImage(grafico);
        
        JFrame testFrame = new JFrame();
        testFrame.setSize(300,300);
        testFrame.setVisible(true);    
               
        JLabel bar= new JLabel();
        bar.setIcon(new ImageIcon(port));
        bar.setBackground(Color.white);
        bar.setOpaque(true);
        bar.setVisible(true);
        
        testFrame.setSize(grafico.getWidth(),grafico.getHeight());
        
        testFrame.add(bar);
        bar.repaint();    
    }
    
}
