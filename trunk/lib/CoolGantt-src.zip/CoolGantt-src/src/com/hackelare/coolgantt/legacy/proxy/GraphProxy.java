package com.hackelare.coolgantt.legacy.proxy;

import com.hackelare.coolgantt.legacy.lib.Task;
import java.util.Date;
import javax.swing.JPopupMenu;
import com.hackelare.coolgantt.legacy.lib.TaskGraphComponent;
import com.hackelare.coolgantt.legacy.model.ColorLabel;
import com.hackelare.coolgantt.legacy.model.TaskImpl;
import com.hackelare.coolgantt.legacy.model.TaskModelImpl;
import com.hackelare.coolgantt.legacy.model.TaskPainterImpl;
import java.awt.Point;

/**
 * Descripción:
 * @version 1.0
 * @author Iuga
 * @cambios
 * @todo
 */

public class GraphProxy {

   private TaskModelImpl _taskModel;
   private TaskGraphComponent _graph;

   public GraphProxy()
   {
        _taskModel = TaskModelImpl.createEmptyModel();
   }

   public TaskGraphComponent buildGraph()
   {
       _graph = new TaskGraphComponent(_taskModel, new TaskPainterImpl());
       _graph.setVisible(true);
       return _graph;
   }

    public void addEtapa(int id, String nombre, Date fechaInicio, Date FechaFin,ColorLabel color)
    {
            EtapaProxy ep = new EtapaProxy(nombre);
            ep.setFechas(fechaInicio, FechaFin);
            ep.setId(id);
            ep.isEditable(true);
            ep.addToModel(_taskModel);
            ep.setColorEtapa(color);
    }

    public void addEtapaNoEditable(int id, String nombre, Date fechaInicio, Date FechaFin)
    {
            EtapaProxy ep = new EtapaProxy(nombre);
            ep.setFechas(fechaInicio, FechaFin);
            ep.setId(id);
            ep.isEditable(false);
            ep.addToModel(_taskModel);
    }

    public void refescarGrafico()
    {
        _graph.repaint();
        // return buildGraph();
    }

    public void setEtapaPredecesora(int idEtapaAntes, int idEtapaDespues)
    {
        TaskImpl[] lista = (TaskImpl[])_taskModel.getTasks();
        
        TaskImpl tAntes = getTarea(lista, idEtapaAntes);
        TaskImpl tDespu = getTarea(lista, idEtapaDespues); 
        
        if(tAntes != null && tDespu != null)
        {   
            TaskImpl[] prev = tDespu.getPredecessors();
            
            if(prev==null)
            {
                prev = new TaskImpl[0];
            }
            
            TaskImpl[] newPrev = new TaskImpl[prev.length+1];
            
            for (int i = 0; i < prev.length; i++) 
            {
                newPrev[i] = prev[i];
            }
            newPrev[newPrev.length-1] = tAntes;
            
            tDespu.setPredecessors(newPrev);
        }
        return;

    }
    
    private TaskImpl getTarea(TaskImpl[] lista, int id)
    {
        for (int i = 0; i < lista.length; i++) 
        {
            TaskImpl ti = lista[i];
            if(ti._id.equals(String.valueOf(id)))
            {
                return ti;
            }
        }
        return null;
    }

    public void setComponentPopupMenu(JPopupMenu jpm)
    {
        _graph.setComponentPopupMenu(jpm);
    }

    public void setFocoFechaActual()
    {
        _graph.focusOnToday();
    }

    public void setZoomIn()
    {
        _graph.scaleUp();
    }

    public void setZoomOut()
    {
        _graph.scaleDown();
    }

    public void moverDerecha()
    {
        _graph.moveRight();
    }

    public void moverIzquierda()
    {
        _graph.moveLeft();
    }

    public void setVistaAnual()
    {
        for (int i = 0; i < 60; i++)
        {
            _graph.scaleDown();
        }
    }

    public void setVistaSemanal()
    {
         for (int i = 0; i < 60; i++)
        {
            _graph.scaleUp();
        }
    }

    public TaskImpl getTarea(Point p)
    {
         Object obj = _graph.findObjectOnPo(p.x,p.y);
         if(obj instanceof Task)
         {
             Task task = (Task)obj;
             return task.getTaskImpl();
         }
         return null;
    }    
    

}
