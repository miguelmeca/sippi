/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

/**
 *
 * @author ghw674
 */
public class CoolGanttFactory 
{
    public static ICoolGantt create()
    {
        return new CoolGanttProxy();
    }
}
