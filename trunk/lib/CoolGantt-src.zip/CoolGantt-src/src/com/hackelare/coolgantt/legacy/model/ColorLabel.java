/*
 * Copyright (C) Jakub Neubauer, 2007
 *
 * This file is part of TaskBlocks
 *
 * TaskBlocks is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * TaskBlocks is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.hackelare.coolgantt.legacy.model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import com.hackelare.coolgantt.legacy.utils.*;

public class ColorLabel {
	
        public static int INT_LIGHTER_MASK_R = 20;
        public static int INT_LIGHTER_MASK_G = 10;
        public static int INT_LIGHTER_MASK_B = 1;
    
	public static ColorLabel[] COLOR_LABELS = new ColorLabel[] {
		new ColorLabel("None", Colors.TASK_COLOR, 0),
		new ColorLabel("Red", new Color(255,120,100), 1),
		new ColorLabel("Orange", new Color(255,200,80), 2),
		new ColorLabel("Yellow", new Color(255,255,100), 3),
		new ColorLabel("Green", new Color(140,255,110), 4),
		new ColorLabel("Gray", new Color(200,200,200), 5),
                new ColorLabel("RojoPastel", new Color(255,120,100), 6),
                new ColorLabel("AmarilloPastel", new Color(255,255,100), 7),
                new ColorLabel("VerdePastel", new Color(140,255,110), 8),
                
                new ColorLabel("TareaColor", new Color(160,190,250), 8)

	};
	
	public Color _color;
	public String _name;
	public Icon  _icon;
	public int _index;

	public ColorLabel(String name, Color color, int index)
        {
		_name = name;
		_color = color;
		_index = index;
		BufferedImage img = new BufferedImage(12, 12, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = (Graphics2D)img.getGraphics();
		g2.setColor(_color);
		g2.fillRect(0,0,img.getWidth(), img.getHeight());
		_icon = new ImageIcon(img);
	}

	public String toString()
        {
		return _name;
	}
       
//            160,190,250
//            170,200,251
//            +20,+10,+1        
        public static Color toLighterColor(Color c)
        {
            int rgb[] = {c.getRed(),c.getGreen(),c.getBlue()};

            rgb[0] = rgb[0]+INT_LIGHTER_MASK_R;
            rgb[1] = rgb[1]+INT_LIGHTER_MASK_G;
            rgb[2] = rgb[2]+INT_LIGHTER_MASK_B;
            
            // Standarize & fix
            for (int i = 0; i < rgb.length; i++) 
            {
                if(rgb[i]>255)
                {
                    rgb[i] = 255;
                }
            }
            
            return new Color(rgb[0],rgb[1],rgb[2]);
        }
}
