/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.util.Date;

/**
 * @author ghw674
 */
public interface ICoolGanttEvent {
        
    /**
     * Override if you want that in the graph shows the project start date
     * @return The Start Date
     */
    public Date inGetProjectStartDate();

    /**
     * Override if you want that in the graph shows the project ends date
     * @return The Start Date
     */    
    public Date inGetProjectEndDate();
    
    /**
     * This event is triggered when the user clicks on a Phase
     * @param id 
     */
    public void outClickPhase(int id);

    /**
     * This event is triggered when the user moves a Phase to another date
     * @param id 
     */    
    public void outMovePhase(int parseInt, Date ini);

    /**
     * This event is triggered when the user extends a Phase to the left
     * @param id 
     */    
    public void outExtendPhaseBackward(int parseInt, Date ini);

    /**
     * This event is triggered when the user extends a Phase to the right
     * @param id 
     */       
    public void outExtendPhaseForward(int parseInt, Date ini);

}
