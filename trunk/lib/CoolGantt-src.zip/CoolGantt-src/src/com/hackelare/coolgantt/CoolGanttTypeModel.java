/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import com.hackelare.coolgantt.legacy.model.ColorLabel;
import java.awt.Color;
import java.util.HashMap;

/**
 *
 * @author ghw674
 */
public class CoolGanttTypeModel {
    
    private HashMap<String, ColorLabel> types;

    public CoolGanttTypeModel() {
        types = new HashMap<String, ColorLabel>();
    }
    
    public void addType(String name, ColorLabel color){
        types.put(name, color);
    }

    public ColorLabel getColor(String type) 
    {
        return types.get(type);
    }
    
}
