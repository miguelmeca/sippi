/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.awt.Point;
import java.util.Date;
import javax.swing.JComponent;

/**
 * Interface to separate the old implementation to the new library.
 * The new module is simpler, encapsulated, robust and configurable.
 * The main advantage is that it is self-contained in a separate jar and the
 * implementation is hidden to the programmer.
 * @author ghw674
 */
public interface ICoolGantt {
   
    /**
     * Gets the Swing component to render the graph.
     * It returns a JPanel, that you must put in a Container to see.
     * @return 
     */
    public JComponent getComponent();
    
    /**
     * Forde the Refresh of the graph and the Component itself with the 
     * actual model
     */
    public void refresh();
    
    /**
     * Asign the model to the graph, it contains the info of the stages and 
     * the relationships between them
     * @param model 
     */
    public void setModel(CoolGanttModel model);
    
    /**
     * Gets the current model to modify. Call refresh after modify it.
     * @return 
     */
    public CoolGanttModel getModel();
    
    /**
     * Add the Phase in the current model
     * @param id
     * @param nombre
     * @param fechaInicio
     * @param FechaFin 
     */
    public void addPhase(int id, String nombre, Date fechaInicio, Date FechaFin);
    public void addPhase(CoolGanttPhase phase);
    
    /**
     * Add the phase in the current model but disabled
     * No behavior is assigned, only the visibility
     * @param id
     * @param nombre
     * @param fechaInicio
     * @param FechaFin 
     */
    public void addPhaseDisabled(int id, String nombre, Date fechaInicio, Date FechaFin);
    public void addPhaseDisabled(CoolGanttPhase phase);

    /**
     * returns the first occurrence of the phase with that id
     * @param id
     * @return 
     */
    public CoolGanttPhase getPhase(int id);
    
    /**
     * Returns the first ocurrence of the pashe in the location Point
     * If not have a Phase returns null
     * @param location
     * @return 
     */
    public CoolGanttPhase getPhase(Point location);
    
    
    /**
     * removes all the occurrences of the phase with that id
     * @param id 
     */
    public void removePhase(int id);
    
    /**
     * Center the graph in the current date
     */
    public void setFocusToday();
    
    /**
     * Zoom In in the graph
     */
    public void setZoomIn();
    
    /**
     * Zoom Out in the graph
     */
    public void setZoomOut();
    
    /**
     * Move the graph to see the elements in the right (bring forward)
     */
    public void moveRight();
    
    /**
     * Move the graph to see the elements in the left (bring backward)
     */
    public void moveLeft();
    
    /**
     * Change the chart view to annual
     */
    public void setYearView();
    
    /**
     * Change the chart view to Weekly
     */
    public void setWeeklyView();

    /**
     * Handle the default Graph Events
     * @param demoEvents 
     */
    public void setEventHandler(ICoolGanttEvent demoEvents);

    /**
     * Message to refresh the data Model into Graph
     */
    public void refreshModel();
    
}
