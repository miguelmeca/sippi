/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;

/**
 * Funciones utiles para trabajar sobre el Gantt
 * @author ghw674
 */
public class CoolGanttUtils {

    /**
     * Transorma el view del gantt a awt.Image
     * @param component
     * @return 
     */
    public static BufferedImage getGanttImage(JComponent component) {
        int w = component.getWidth();
        int h = component.getHeight();
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bi.createGraphics();
        component.paint(g);
        return bi;
    }

}
