/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author ghw674
 */
public class CoolGanttFactoryTest {
    
    public CoolGanttFactoryTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of create method, of class CoolGanttFactory.
     */
    @Test
    public void testCreate() {
        System.out.println("++ CoolGanttFactory Test");

        ICoolGantt result = CoolGanttFactory.create();
        
        if(result instanceof CoolGanttProxy)
        {
            System.out.println("++ Test Passed!");
        }
        else
        {
            fail("-- The returned instance is not a graph proxy");
        }
        
    }
}
