/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hackelare.coolgantt;

import java.awt.Point;
import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JFrame;
import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author iuga
 */
public class CoolGanttProxyTest {
    
    private CoolGanttProxy ganttProxy;
    
    public CoolGanttProxyTest() {
    }
    
    @Before
    public void setUp() {
        // New Object
        this.ganttProxy = new CoolGanttProxy();
        
        // Init with data
        CoolGanttPhase p1 = new CoolGanttPhase();
        p1.setStartDate(new Date());
        p1.setStartDate(new Date());
        p1.setNombre("Test Phase 1");
        p1.setEditable(true);
        
        this.ganttProxy.addPhase(p1);

        JFrame testFrame = new JFrame();
        testFrame.setLayout(new java.awt.BorderLayout());
        
        JComponent p = this.ganttProxy.getComponent();
        
        testFrame.add(p, java.awt.BorderLayout.CENTER);
        
        testFrame.setVisible(true);
        p.setVisible(true);
        testFrame.pack();
    }
    
    @After
    public void tearDown() {
        this.ganttProxy = null;
    }

    /**
     * Test of getPhase method, of class CoolGanttProxy.
     */
    @Test
    public void testGetPhase_Point() {
        Point location = new Point(20,20);

        CoolGanttPhase result = this.ganttProxy.getPhase(location);
    }
}
